import 'package:flutter/material.dart';

import '../repositories/sesi_repository.dart';

class PapanDiagnostikPenyimpanan extends StatefulWidget {
  final SesiRepository repository;

  const PapanDiagnostikPenyimpanan({
    super.key,
    required this.repository,
  });

  @override
  State<PapanDiagnostikPenyimpanan> createState() =>
      _PapanDiagnostikPenyimpananState();
}

class _PapanDiagnostikPenyimpananState
    extends State<PapanDiagnostikPenyimpanan> {
  bool _sedangMengintip = false;
  bool _sudahMengintip = false;
  String? _hasilIntip;

  Future<void> _intip() async {
    setState(() => _sedangMengintip = true);

    try {
      final String? hasil = await widget.repository.intipMentah();

      if (!mounted) return;

      setState(() {
        _hasilIntip = hasil;
        _sudahMengintip = true;
        _sedangMengintip = false;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _hasilIntip = null;
        _sudahMengintip = true;
        _sedangMengintip = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Diagnostik Penyimpanan',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            Text(widget.repository.nama),
            const SizedBox(height: 4),
            Text(widget.repository.keterangan),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: _sedangMengintip ? null : _intip,
              child: Text(
                _sedangMengintip ? 'Memeriksa...' : 'Intip Token',
              ),
            ),
            if (_sudahMengintip) ...<Widget>[
              const SizedBox(height: 12),
              Text(
                _hasilIntip == null
                    ? 'Token mentah tidak tersedia melalui API ini.'
                    : 'Data yang terbaca: $_hasilIntip',
              ),
            ],
          ],
        ),
      ),
    );
  }
}