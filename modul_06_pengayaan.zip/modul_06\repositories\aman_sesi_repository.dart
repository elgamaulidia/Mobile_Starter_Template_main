
import 'dart:convert';

import '../../../modul_06/models/sesi_pengguna.dart';
import '../storage/penyimpanan_aman_platform.dart';
import 'sesi_repository.dart';

class AmanSesiRepository implements SesiRepository {
  final PenyimpananAmanPlatform penyimpanan;
  static const String kunciSesi = 'sesi_pengguna';

  AmanSesiRepository({required this.penyimpanan});

  @override
  String get nama => 'Penyimpanan Aman';

  @override
  String get keterangan =>
      'Sesi disimpan menggunakan flutter_secure_storage.';

  @override
  bool get bertahanSetelahRestart => true;

  @override
  Future<SesiPengguna?> baca() async {
    final String? data = await penyimpanan.baca(kunciSesi);

    if (data == null || data.isEmpty) {
      return null;
    }

    final dynamic json = jsonDecode(data);

    if (json is! Map<String, dynamic>) {
      return null;
    }

    return SesiPengguna.fromJson(json);
  }

  @override
  Future<void> simpan(SesiPengguna sesi) async {
    await penyimpanan.tulis(
      kunciSesi,
      jsonEncode(sesi.toJson()),
    );
  }

  @override
  Future<void> hapus() async {
    await penyimpanan.hapus(kunciSesi);
  }

  @override
  Future<bool> adaSesi() async {
    final String? data = await penyimpanan.baca(kunciSesi);
    return data != null && data.isNotEmpty;
  }

  @override
  Future<String?> intipMentah() => penyimpanan.bacaMentah(kunciSesi);
}
